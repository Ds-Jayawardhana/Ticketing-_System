package com.example.Backend.services;

public interface TicketingService {
    void userStart();
    void stopSystem();
}
